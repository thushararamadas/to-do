import React from 'react'
import Todoapp from './components/screens/Todoapp'
import './App.css'

function App() {
  return (
    <Todoapp/>
  )
}

export default App;

